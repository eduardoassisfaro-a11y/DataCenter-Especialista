# Microsoft Data Center — Projeto CPQ11

## Visão geral
Projeto técnico voltado para infraestrutura crítica de Data Center, com foco em **automação predial (BAS)**, **HVAC**, **sensores ambientais**, **pressão diferencial** e **infraestrutura de instrumentação**.

## Escopo técnico
- Implementação de sistema BAS completo
- Integração com AHUs em ambiente crítico
- Instalação de sensores ambientais
- Controle de pressão diferencial em Hot/Cold Aisle
- Infraestrutura de cabeamento e instrumentação
- Apoio em comissionamento e troubleshooting

## Sistemas envolvidos

### BAS (Building Automation System)
- Controladores centrais
- Painéis com transmissores de pressão
- Monitoramento em tempo real
- Integração com equipamentos HVAC

### HVAC
- Integração com múltiplas AHUs
- Controle térmico em ambiente crítico
- Monitoramento de ar de entrada, retorno e plenum

### Pressão diferencial
- Controle de fluxo de ar em Hot/Cold Aisle
- Sensores ΔP distribuídos por células
- Tubulação pneumática dedicada

### Sensores e instrumentação
- Temperatura
- Umidade
- Pressão
- Qualidade da água (pH, cloro, condutividade)

### Infraestrutura física
- Eletrocalhas metálicas
- Eletrodutos galvanizados
- Estruturas Unistrut
- Suportes metálicos e vergalhões galvanizados
- Segregação de sistemas críticos

## Normas e padrões
- ABNT NBR 5410
- ABNT NBR 16665
- ANSI/TIA-942
- Microsoft Data Center Standards

## Resultados técnicos
- Alta disponibilidade
- Eficiência térmica
- Monitoramento contínuo
- Infraestrutura escalável
- Padrão hyperscale

## Competências demonstradas
- Leitura e interpretação de projetos
- Instalação de infraestrutura crítica
- Integração BAS + HVAC
- Monitoramento ambiental
- Apoio ao comissionamento
- Troubleshooting em ambiente de missão crítica

## Aplicação profissional
Este projeto demonstra aderência para posições como:
- Data Center Technician
- Critical Environment Technician
- Data Center Infrastructure Specialist
- BAS / HVAC Specialist
- Facilities Support Technician
