# Azure Data Center Labs

## Objetivo
Demonstrar a transição da experiência em infraestrutura crítica de Data Center para ambientes em **Microsoft Azure**, com foco em operação, monitoramento, disponibilidade e administração básica.

## Lab 1 — Virtual Machines
### Itens trabalhados
- Criação de conta Azure
- Provisionamento de VM Windows ou Linux
- Acesso via RDP/SSH
- Conceitos de disponibilidade e custo

### Competências
- IaaS
- Provisionamento
- Acesso remoto
- Gestão inicial de recursos

## Lab 2 — Networking
### Itens trabalhados
- Criação de VNet
- Criação de Subnet
- Configuração de NSG
- Regras básicas de acesso

### Competências
- Rede virtual
- Segurança de borda
- Segmentação lógica
- Conectividade

## Lab 3 — Azure Monitor
### Itens trabalhados
- Métricas
- Logs
- Alertas
- Monitoramento de recursos

### Competências
- Observabilidade
- Troubleshooting
- Monitoramento proativo
- Correlação com operação de BAS

## Lab 4 — Storage
### Itens trabalhados
- Storage Account
- Upload de arquivos
- Tipos de redundância
- Noções de backup

### Competências
- Armazenamento em nuvem
- Disponibilidade
- Resiliência
- Gestão básica de dados

## Certificações relacionadas
- AZ-900 (em andamento)
- AZ-104 (planejado)

## Diferencial profissional
Minha experiência prática com Data Centers, BAS, HVAC e infraestrutura crítica me permite interpretar a cloud com uma visão mais madura de:
- Alta disponibilidade
- Missão crítica
- Monitoramento
- Operação segura
- Continuidade de serviço

## Aplicação profissional
Este projeto fortalece o posicionamento para vagas como:
- Azure Administrator Trainee / Junior
- Cloud Infrastructure Analyst
- Data Center + Cloud Operations
- Technical Support Engineer
