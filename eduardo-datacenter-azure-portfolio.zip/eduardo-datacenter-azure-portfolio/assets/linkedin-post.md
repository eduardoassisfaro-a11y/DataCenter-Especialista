# LinkedIn Post

Hoje compartilho um pouco da minha atuação em infraestrutura crítica aplicada a Data Centers.

No projeto **CPQ11 (Data Center Microsoft)**, trabalhei com sistemas essenciais para a operação segura e eficiente do ambiente, incluindo:

- BAS (Building Automation System)
- Integração com AHUs
- Controle de pressão diferencial (Hot/Cold Aisle)
- Sensores ambientais
- Infraestrutura de instrumentação e cabeamento

Além da experiência prática em campo, sigo avançando para a área de **Cloud Infrastructure com Microsoft Azure**, conectando a base de infraestrutura física com monitoramento, disponibilidade e operação em nuvem.

Meu objetivo é atuar cada vez mais em ambientes de missão crítica, onde engenharia, operação e tecnologia precisam funcionar com precisão.

#DataCenter #Azure #BAS #HVAC #CriticalEnvironment #Infrastructure #Microsoft
